

export function Index(){
    return(
        <h1>Pagina Index</h1>
    )
}