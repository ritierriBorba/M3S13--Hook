

export function Config(){
    return(
        <h1>Pagina Configuração</h1>
    )
}