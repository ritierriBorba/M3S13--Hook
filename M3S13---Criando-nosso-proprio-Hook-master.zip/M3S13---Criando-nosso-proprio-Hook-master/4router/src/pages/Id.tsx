

export function Id(){
    return(
        <h1>Pagina itens</h1>
    )
}