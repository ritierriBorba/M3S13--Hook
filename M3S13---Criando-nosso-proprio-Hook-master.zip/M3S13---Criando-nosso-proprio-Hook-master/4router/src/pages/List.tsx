

export function List(){
    return(
        <h1>Pagina Lista</h1>
    )
}